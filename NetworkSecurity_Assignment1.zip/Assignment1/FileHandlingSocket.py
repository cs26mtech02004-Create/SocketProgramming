import os
import my_enc_decrp as ENC_DECRP

def filemgmtcommand(cmd, dh_secretkey, reqd_filename=None):
    base_dir = "./myFileDirectory"
    if cmd == "LIST":
        print("--- Directory Listing ---")
        lists = []
        for file in os.listdir(base_dir):
            lists.append(file)
        print(lists)
        list_str = " ".join(lists) #list ko str m convert karna
        print("list sent", list_str)
        encLIST = ENC_DECRP.aes_encrypt(list_str.encode(), dh_secretkey)
        print(f"encrypted cipher of LIST command = {encLIST}")
        return encLIST


    file_path = os.path.abspath(os.path.join(base_dir, reqd_filename))
    if cmd not in ("GET", "INFO", "SIZE","LIST"):
        return ENC_DECRP.aes_encrypt("UNKNOWN_COMMAND".encode(), dh_secretkey)

    if not reqd_filename or not os.path.exists(file_path):
        print(f"Error: File '{reqd_filename}' not found.")
        return ENC_DECRP.aes_encrypt("file not found".encode(), dh_secretkey)

    match cmd:
        case "GET":
            seq_no = 0
            packets = []
            print(f"--- Content of {reqd_filename} ---")
            with open(file_path, "rb") as f:
                while True:
                    chunk = f.read(1024)
                    if not chunk:
                        break
                    cipher_data = ENC_DECRP.aes_encrypt(chunk, dh_secretkey)
                    mac = ENC_DECRP.compute_mac(cipher_data, seq_no, dh_secretkey)
                    header = f"{seq_no}|{len(cipher_data)}|\n".encode()
                    packet = header + cipher_data + mac
                    packets.append(packet)
                    seq_no += 1
                packets.append(b"EOF")
            print("chunks sended from filemgmtcommand of GET command")
            print(f"The Cipher of GET command = {packets}")
            return packets

        case "INFO":
            print(f"--- Stats for {reqd_filename} ---")
            info = str(os.stat(file_path)).encode()
            print(f"The Cipher of INFO command= {info}")
            return ENC_DECRP.aes_encrypt(info, dh_secretkey)

        case "SIZE":
            size = os.stat(file_path).st_size
            sizeinfo = f"File size: {size} bytes".encode()
            print(f"size of file: {sizeinfo}")
            return ENC_DECRP.aes_encrypt(sizeinfo, dh_secretkey) #send kiya encyption byte data server ko


# ---- Test k liye data h,  after testing please comment it back----
#print(filemgmtcommand("SIZE","1343445456565","file1.txt"))