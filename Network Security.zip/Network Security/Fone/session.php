<?php
session_set_cookie_params([
    'lifetime' => 0,         // session cookie
    'path' => '/',
    'domain' => '',
    'secure' => false,       // true if using HTTPS
    'httponly' => true,
    'samesite' => 'Strict'
]);

session_start();

// Auto logout after 15 minutes
$timeout = 120;

if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY']) > $timeout) {
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit();
}

$_SESSION['LAST_ACTIVITY'] = time();
?>
