<?php
$host = "localhost";
$user = "root";
$pass = "root";
$db = "login_db";
$conn = mysqli_connect($host, $user, $pass, $db);
if(!$conn){
    die("database connection failed".mysql_error);
}
?>